/* ============ Panneaux : paramètres, galerie, éditeur de widget ============ */

/* ---------- Aperçu mis à l'échelle (galerie + éditeur) ---------- */
function previewBox(type, cfg, { demo = true, h: height = 168 } = {}) {
  const box = h("div", { class: "pv", style: { height: height + "px" } });
  const inner = h("div", { class: "pv-in widget wt-" + type });
  inner.style.pointerEvents = "none";
  box.append(inner);
  const def = WIDGETS[type];
  let cleanup = def.mount(inner, cfg, { id: "pv", demo, patch() {}, edit() {} });
  const fit = () => {
    inner.style.transform = "translate(-50%,-50%)";
    const w = inner.offsetWidth, hh = inner.offsetHeight;
    if (!w || !hh) return;
    const k = Math.min(1, (box.clientWidth - 28) / w, (box.clientHeight - 28) / hh);
    inner.style.transform = `translate(-50%,-50%) scale(${k})`;
  };
  const ro = new ResizeObserver(fit);
  ro.observe(box); ro.observe(inner);
  box.update = (newCfg) => {
    if (cleanup) cleanup();
    inner.innerHTML = ""; inner.className = "pv-in widget wt-" + type;
    cleanup = def.mount(inner, newCfg, { id: "pv", demo, patch() {}, edit() {} });
    requestAnimationFrame(fit);
  };
  box.destroy = () => { if (cleanup) cleanup(); ro.disconnect(); };
  return box;
}

/* ---------- Galerie de widgets ---------- */
let galleryPreviews = [];
function openGallery() {
  const d = $("dlgGallery");
  galleryPreviews.forEach((p) => p.destroy());
  galleryPreviews = [];
  let query = "";
  const body = h("div", { class: "gal-body" });
  const search = h("input", { type: "search", placeholder: "Rechercher un widget", class: "gal-search", onInput: (e) => { query = e.target.value.toLowerCase().trim(); draw(); } });
  const draw = () => {
    galleryPreviews.forEach((p) => p.destroy());
    galleryPreviews = [];
    body.innerHTML = "";
    const cats = [...new Set(WIDGET_ORDER.map((t) => WIDGETS[t].cat))];
    let any = false;
    for (const cat of cats) {
      const list = WIDGET_ORDER.filter((t) => WIDGETS[t].cat === cat && (!query || (WIDGETS[t].name + " " + WIDGETS[t].desc).toLowerCase().includes(query)));
      if (!list.length) continue;
      any = true;
      const grid = h("div", { class: "gal-grid" });
      for (const t of list) {
        const def = WIDGETS[t];
        const used = def.single && state.widgets.some((w) => w.type === t);
        const pv = previewBox(t, { ...def.defaults, ...def.sample });
        galleryPreviews.push(pv);
        grid.append(h("article", { class: "gcard" + (used ? " used" : "") },
          pv,
          h("div", { class: "gmeta" },
            h("div", {}, h("b", {}, def.name), h("small", {}, def.desc)),
            h("button", { type: "button", class: "gadd", disabled: used, "aria-label": "Ajouter " + def.name, title: used ? "Déjà affiché" : "Ajouter",
              html: svg(used ? "check" : "plus"), onClick: () => { addWidget(t); closeDlg(d); } }))));
      }
      body.append(h("h4", { class: "gal-cat" }, cat), grid);
    }
    if (!any) body.append(h("p", { class: "empty" }, "Aucun widget ne correspond."));
  };
  d.innerHTML = "";
  d.append(
    h("header", { class: "sheet-h" },
      h("div", {}, h("h2", {}, "Widgets"), h("p", {}, "Choisissez ce que vous voulez afficher sur votre page.")),
      h("button", { class: "xbtn", "aria-label": "Fermer", html: svg("close"), onClick: () => closeDlg(d) })),
    h("div", { class: "gal-tools" }, icon("search", "gs"), search),
    body);
  draw();
  openDlg(d);
  setTimeout(() => search.focus(), 60);
}

/* ---------- Éditeur de widget ---------- */
let editorPreview = null, editorWidgetId = null;
function openWidgetEditor(id) {
  const w = state.widgets.find((x) => x.id === id);
  if (!w) return;
  editorWidgetId = id;
  const def = WIDGETS[w.type], d = $("dlgWidget");
  if (editorPreview) editorPreview.destroy();
  const pv = editorPreview = previewBox(w.type, w.cfg, { demo: w.type !== "weather" || !!w.cfg.city, h: 190 });
  const stage = h("div", { class: "pv-stage" }, pv);
  const list = h("div", { class: "ed-list" });

  const commit = (k, v, live) => {
    w.cfg[k] = v;
    if (def.onChange) def.onChange(w.cfg, k);
    save();
    pv.update(w.cfg);
    refreshWidget(w.id);
    if (!live) { drawList(); }
  };
  const control = (f) => {
    const c = w.cfg;
    switch (f.t) {
      case "segment": return ui.segment(f.opts, () => c[f.k], (v) => commit(f.k, v));
      case "switch": return ui.switch(() => c[f.k], (v) => commit(f.k, v));
      case "range": return ui.range({ min: f.min, max: f.max, step: f.step, fmt: f.fmt, get: () => c[f.k], set: (v, live) => commit(f.k, v, live) });
      case "color": return ui.swatches(f.set, () => c[f.k], (v) => commit(f.k, v, true), true);
      case "fonts": return null;
      case "city": return null;
    }
  };
  function drawList() {
    list.innerHTML = "";
    let group = null, rows = [], title = null;
    const flush = () => { if (rows.length) list.append(ui.group(title, rows)); rows = []; };
    for (const f of def.fields(w.cfg)) {
      if (f.sec) { flush(); title = f.sec; }
      if (f.t === "fonts") {
        rows.push(h("div", { class: "row stack" }, h("div", { class: "rtxt" }, h("b", {}, f.l)), fontGrid(w.cfg, (v) => commit("font", v))));
      } else if (f.t === "city") {
        rows.push(h("div", { class: "row stack" }, h("div", { class: "rtxt" }, h("b", {}, f.l)), cityPicker(w.cfg, (city) => { commit("city", city); pv.destroy(); editorPreview = previewBox(w.type, w.cfg, { demo: false, h: 190 }); stage.innerHTML = ""; stage.append(editorPreview); })));
      } else {
        rows.push(ui.row({ label: f.l, control: control(f) }));
      }
    }
    flush();
  }
  drawList();

  d.innerHTML = "";
  d.append(
    h("header", { class: "sheet-h compact" },
      h("div", { class: "ed-title" }, h("i", { class: "rico lg", style: { background: def.color }, html: svg(def.ic) }), h("h2", {}, def.name)),
      h("button", { class: "xbtn", "aria-label": "Fermer", html: svg("close"), onClick: () => closeDlg(d) })),
    stage,
    h("div", { class: "ed-scroll" }, list),
    h("footer", { class: "sheet-f" },
      ui.button("Supprimer", { kind: "danger", ic: "trash", onClick: () => { closeDlg(d); removeWidget(w.id); } }),
      ui.button("OK", { kind: "primary", onClick: () => closeDlg(d) })));
  openDlg(d);
}

function fontGrid(cfg, set) {
  const wrap = h("div", { class: "fontgrid" });
  const draw = () => {
    wrap.innerHTML = "";
    for (const [key, f] of Object.entries(FONTS)) {
      wrap.append(h("button", { type: "button", class: "fchip" + (cfg.font === key ? " on" : ""), onClick: () => { set(key); } },
        h("span", { class: "fs", style: { fontFamily: f.css, fontWeight: f.w ? clamp(300, f.w[0], f.w[1]) : 400, fontSize: 24 * f.k + "px" } }, "12:34"),
        h("small", {}, f.n)));
    }
  };
  draw();
  return wrap;
}

function cityPicker(cfg, set) {
  const wrap = h("div", { class: "city" });
  const cur = h("div", { class: "city-cur" });
  const input = h("input", { type: "search", class: "city-in", placeholder: "Rechercher une ville…", autocomplete: "off" });
  const results = h("div", { class: "city-res" });
  const paintCur = () => {
    cur.innerHTML = "";
    if (cfg.city) cur.append(icon("location"), h("span", {}, cfg.city.name, cfg.city.region ? h("small", {}, " " + cfg.city.region) : null));
    else cur.append(h("span", { class: "muted" }, "Aucune ville sélectionnée"));
  };
  paintCur();
  let timer, seq = 0;
  input.addEventListener("input", () => {
    clearTimeout(timer);
    const q = input.value.trim();
    if (q.length < 2) { results.innerHTML = ""; return; }
    timer = setTimeout(async () => {
      const my = ++seq;
      try {
        const r = await fetch("https://geocoding-api.open-meteo.com/v1/search?name=" + encodeURIComponent(q) + "&count=6&language=fr&format=json");
        const j = await r.json();
        if (my !== seq) return;
        results.innerHTML = "";
        const list = j.results || [];
        if (!list.length) results.append(h("div", { class: "city-none" }, "Aucun résultat"));
        for (const it of list) {
          const region = [it.admin1, it.country].filter(Boolean).join(", ");
          results.append(h("button", { type: "button", class: "city-it", onClick: () => {
            set({ name: it.name, region, lat: it.latitude, lon: it.longitude });
            results.innerHTML = ""; input.value = ""; paintCur();
          } }, h("b", {}, it.name), h("small", {}, region)));
        }
      } catch { results.innerHTML = ""; results.append(h("div", { class: "city-none" }, "Recherche impossible hors connexion")); }
    }, 250);
  });
  const gps = ui.button("Utiliser ma position", { kind: "soft", ic: "location", onClick: () => {
    if (!navigator.geolocation) return toast("Géolocalisation indisponible");
    navigator.geolocation.getCurrentPosition(
      (p) => { set({ name: "Ma position", region: "", lat: +p.coords.latitude.toFixed(3), lon: +p.coords.longitude.toFixed(3), gps: true }); paintCur(); },
      () => toast("Impossible d'obtenir votre position"), { timeout: 8000 });
  } });
  wrap.append(cur, input, results, gps);
  return wrap;
}

/* ---------- Fenêtre Paramètres ---------- */
const ACCENTS = [["Bleu", "#0a84ff"], ["Violet", "#bf5af2"], ["Rose", "#ff375f"], ["Orange", "#ff9f0a"], ["Vert", "#30d158"], ["Graphite", "#98989d"]];
let settingsPage = "widgets";

const SETTINGS_PAGES = [
  { id: "widgets", label: "Widgets", ic: "widgets", color: "linear-gradient(135deg,#4facfe,#0a84ff)" },
  { id: "wallpaper", label: "Fond d'écran", ic: "image", color: "linear-gradient(135deg,#ff6482,#bf5af2)" },
  { id: "shortcuts", label: "Raccourcis", ic: "apps", color: "linear-gradient(135deg,#ffb340,#ff7a00)" },
  { id: "appearance", label: "Apparence", ic: "palette", color: "linear-gradient(135deg,#6e6bff,#8e44ff)" },
  { id: "data", label: "Données", ic: "data", color: "linear-gradient(135deg,#8e8e93,#5a5a5f)" },
  { id: "about", label: "À propos", ic: "info", color: "linear-gradient(135deg,#5ac8fa,#0a84ff)" }
];

function openSettings(page) {
  if (page) settingsPage = page;
  const d = $("dlgSettings");
  d.innerHTML = "";
  const side = h("aside", { class: "win-side" },
    h("div", { class: "win-title" }, "Paramètres"),
    h("nav", {}, SETTINGS_PAGES.map((p) => h("button", { type: "button", class: "sidei" + (p.id === settingsPage ? " on" : ""), "data-p": p.id,
      onClick: () => { settingsPage = p.id; renderSettings(); } },
      h("i", { class: "rico", style: { background: p.color }, html: svg(p.ic) }), p.label))));
  const main = h("div", { class: "win-main" },
    h("header", { class: "win-h" }, h("h2", { id: "setTitle" }), h("button", { class: "xbtn", "aria-label": "Fermer", html: svg("close"), onClick: () => closeDlg(d) })),
    h("div", { class: "win-scroll", id: "setBody" }));
  d.append(side, main);
  renderSettings();
  openDlg(d);
}

function renderSettings() {
  const d = $("dlgSettings");
  if (!d.open && !d.firstChild) return;
  d.querySelectorAll(".sidei").forEach((b) => b.classList.toggle("on", b.dataset.p === settingsPage));
  const p = SETTINGS_PAGES.find((x) => x.id === settingsPage);
  $("setTitle").textContent = p.label;
  const body = $("setBody");
  const keep = body.scrollTop;
  body.innerHTML = "";
  const page = h("div", { class: "page" }, PAGES[settingsPage]());
  body.append(page);
  body.scrollTop = settingsPage === body.dataset.page ? keep : 0;
  body.dataset.page = settingsPage;
}

const S = () => state.settings;
const setS = (k, v, apply) => { state.settings[k] = v; if (apply) apply(); save(); };

const PAGES = {
  widgets() {
    const rows = state.widgets.map((w) => {
      const def = WIDGETS[w.type];
      return h("div", { class: "row tap wrow", onClick: () => openWidgetEditor(w.id) },
        h("i", { class: "rico", style: { background: def.color }, html: svg(def.ic) }),
        h("div", { class: "rtxt" }, h("b", {}, def.name), h("small", {}, def.sub(w.cfg))),
        h("div", { class: "rctl" },
          h("button", { type: "button", class: "mini danger", "aria-label": "Retirer", title: "Retirer", html: svg("trash"), onClick: (e) => { e.stopPropagation(); removeWidget(w.id); renderSettings(); } })),
        h("span", { class: "rchev", html: svg("chevron") }));
    });
    return [
      h("div", { class: "hero" },
        h("div", { class: "hero-ic", html: svg("widgets") }),
        h("div", {}, h("b", {}, "Vos widgets"), h("p", {}, "Ajoutez, réglez et déplacez les éléments de votre page d'accueil.")),
        ui.button("Ajouter un widget", { kind: "primary", ic: "plus", onClick: () => { closeDlg($("dlgSettings")); openGallery(); } })),
      ui.group("Sur l'écran", rows.length ? rows : [h("div", { class: "row" }, h("div", { class: "rtxt" }, h("small", {}, "Aucun widget pour le moment.")))],
        "Astuce : en mode « Modifier l'écran », faites glisser un widget pour le placer où vous voulez."),
      ui.group("Disposition", [
        ui.row({ icon: "move", color: "linear-gradient(135deg,#8e8e93,#5a5a5f)", label: "Modifier l'écran", sub: "Déplacer widgets et raccourcis", chevron: true, onClick: () => { closeDlg($("dlgSettings")); setEditing(true); } }),
        ui.row({ icon: "refresh", color: "linear-gradient(135deg,#8e8e93,#5a5a5f)", label: "Rétablir la disposition d'origine", sub: "Logo, horloge et recherche", chevron: true, onClick: async () => {
          if (await confirmBox("Les widgets actuels seront remplacés par la disposition d'origine (logo, horloge, recherche). Vos raccourcis ne changent pas.", "Rétablir", "Rétablir la disposition", true)) { resetWidgets(); renderSettings(); }
        } })
      ])
    ];
  },

  wallpaper() {
    const bg = state.bg || state.settings.bgUrl;
    const prev = h("div", { class: "wp-prev", style: { backgroundImage: `url("${bg || "bg-default.jpg"}")` } },
      h("div", { class: "wp-over" },
        ui.button("Choisir une image…", { kind: "glass", ic: "image", onClick: () => $("bgFile").click() }),
        bg ? ui.button("Retirer", { kind: "glass", onClick: () => { state.bg = ""; state.settings.bgUrl = ""; renderBg(); save(); renderSettings(); } }) : null));
    prev.style.filter = "";
    return [
      prev,
      ui.group("Image", [
        ui.row({ label: "Lien d'une image", sub: "Une adresse https:// vers une image", stack: true, control: h("input", { type: "text", class: "tf", value: S().bgUrl || "", placeholder: "https://…/image.jpg",
          onChange: (e) => { state.settings.bgUrl = e.target.value.trim(); state.bg = ""; renderBg(); save(); renderSettings(); } }) })
      ]),
      ui.group("Réglages", [
        ui.row({ label: "Flou", control: ui.range({ min: 0, max: 20, get: () => S().blur, fmt: (v) => v + " px", set: (v) => setS("blur", v, renderBg) }) }),
        ui.row({ label: "Assombrissement", control: ui.range({ min: 0, max: 80, get: () => S().dim, fmt: (v) => v + " %", set: (v) => setS("dim", v, renderBg) }) }),
        ui.row({ label: "Effet de parallaxe", sub: "Le fond suit légèrement la souris", control: ui.switch(() => S().parallax, (v) => setS("parallax", v, () => { if (!v) $("bg").style.translate = ""; })) })
      ])
    ];
  },

  shortcuts() {
    return [
      ui.group("Affichage", [
        ui.row({ label: "Taille des icônes", control: ui.range({ min: 40, max: 110, get: () => S().size, fmt: (v) => v + " px", set: (v) => setS("size", v, renderTiles) }) }),
        ui.row({ label: "Afficher les noms", control: ui.switch(() => S().labels, (v) => setS("labels", v, applyBody)) })
      ]),
      ui.group("Gérer", [
        ui.row({ icon: "plus", color: "linear-gradient(135deg,#30d158,#1fa84a)", label: "Ajouter un raccourci", chevron: true, onClick: () => { closeDlg($("dlgSettings")); openShortcutDialog(); } }),
        ui.row({ icon: "move", color: "linear-gradient(135deg,#8e8e93,#5a5a5f)", label: "Réorganiser", sub: "Déplacer, modifier ou supprimer", chevron: true, onClick: () => { closeDlg($("dlgSettings")); setEditing(true); } }),
        ui.row({ icon: "star", color: "linear-gradient(135deg,#ffb340,#ff7a00)", label: "Sites les plus visités", sub: "Ajouter vos raccourcis Chrome", chevron: true, onClick: importTopSites })
      ], `${state.shortcuts.length} raccourci${state.shortcuts.length > 1 ? "s" : ""} actuellement.`),
      ui.group(null, [
        ui.row({ icon: "refresh", color: "linear-gradient(135deg,#ff6482,#ff375f)", label: "Restaurer les raccourcis par défaut", chevron: true, onClick: restoreDefaults })
      ])
    ];
  },

  appearance() {
    return [
      ui.group("Couleur d'accentuation", [
        h("div", { class: "row stack" }, h("div", { class: "accents" }, ACCENTS.map(([n, c]) =>
          h("button", { type: "button", class: "acc" + (S().accent === c ? " on" : ""), style: { "--c": c }, title: n, "aria-label": n,
            onClick: () => { setS("accent", c, applyBody); renderSettings(); } }, h("span", { html: svg("check") }), h("small", {}, n)))))
      ]),
      ui.group("Verre", [
        ui.row({ label: "Flou", sub: "Raccourcis, widgets et recherche", control: ui.range({ min: 0, max: 60, get: () => S().gblur, fmt: (v) => v + " px", set: (v) => setS("gblur", v, applyBody) }) }),
        ui.row({ label: "Opacité", control: ui.range({ min: 0, max: 100, get: () => S().galpha, fmt: (v) => v + " %", set: (v) => setS("galpha", v, applyBody) }) })
      ]),
      ui.group("Mouvement", [
        ui.row({ label: "Animations", sub: "Entrées, survols, logo animé", control: ui.switch(() => S().anim, (v) => setS("anim", v, renderBg)) }),
        ui.row({ label: "Particules flottantes", control: ui.switch(() => S().particles, (v) => setS("particles", v, applyFx)) })
      ])
    ];
  },

  data() {
    return [
      ui.group("Sauvegarde", [
        ui.row({ icon: "download", color: "linear-gradient(135deg,#0a84ff,#0060d0)", label: "Exporter la configuration", sub: "Widgets, raccourcis et réglages (JSON)", chevron: true, onClick: exportConfig }),
        ui.row({ icon: "upload", color: "linear-gradient(135deg,#30d158,#1fa84a)", label: "Importer une configuration", chevron: true, onClick: () => $("importFile").click() })
      ]),
      ui.group("Zone sensible", [
        ui.row({ icon: "trash", color: "linear-gradient(135deg,#ff6482,#ff375f)", label: "Tout réinitialiser", sub: "Widgets, raccourcis, réglages et fond d'écran", danger: true, chevron: true, onClick: async () => {
          if (await confirmBox("Tous vos réglages, widgets, raccourcis et votre fond d'écran seront remplacés par ceux d'origine. Cette action est irréversible.", "Tout réinitialiser", "Réinitialiser", true)) { resetAll(); renderSettings(); }
        } })
      ])
    ];
  },

  about() {
    const v = (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : "";
    return [
      h("div", { class: "about" }, h("div", { class: "about-logo" }, $("logoTpl").content.firstElementChild.cloneNode(true)), h("b", {}, "New Interface"), h("small", {}, "Version " + v)),
      ui.group(null, [
        ui.row({ label: "Météo", sub: "Données Open-Meteo.com, sans clé API (usage non commercial)" }),
        ui.row({ label: "Polices", sub: "Outfit, Quicksand, Playfair Display, JetBrains Mono, Orbitron, Bebas Neue, Caveat — licence SIL OFL" })
      ])
    ];
  }
};
