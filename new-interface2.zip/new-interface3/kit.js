/* ============ Kit UI : helpers DOM, icônes, contrôles style Apple ============ */
const $ = (id) => document.getElementById(id);

function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === "class") el.className = v;
    else if (k === "html") el.innerHTML = v;
    else if (k === "style" && typeof v === "object") { for (const [p, val] of Object.entries(v)) { if (p.startsWith("--")) el.style.setProperty(p, val); else el.style[p] = val; } }
    else if (k.startsWith("on")) el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === "value" || k === "checked" || k === "disabled") el[k] = v;
    else el.setAttribute(k, v === true ? "" : v);
  }
  const add = (c) => {
    if (c == null || c === false) return;
    if (Array.isArray(c)) c.forEach(add);
    else el.append(c.nodeType ? c : document.createTextNode(c));
  };
  kids.forEach(add);
  return el;
}

const ICONS = {
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  chevron: '<path d="m9.5 6 6 6-6 6"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  trash: '<path d="M4.5 7h15M9.5 7V4.5h5V7M6.5 7l.8 12.5h9.4L17.5 7M10 11v5M14 11v5"/>',
  widgets: '<rect x="3.5" y="3.5" width="7.5" height="7.5" rx="2"/><rect x="13" y="3.5" width="7.5" height="7.5" rx="2"/><rect x="3.5" y="13" width="7.5" height="7.5" rx="2"/><rect x="13" y="13" width="7.5" height="7.5" rx="2"/>',
  image: '<rect x="3.5" y="4.5" width="17" height="15" rx="3"/><circle cx="9" cy="10" r="1.7"/><path d="m4 17 5-4.5 3.5 3 3-2.5 4.5 4"/>',
  apps: '<rect x="4" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.8"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.8"/>',
  palette: '<path d="M12 3.5a8.5 8.5 0 1 0 0 17c1.3 0 2-.8 2-1.8 0-1.4-1-1.6-1-2.8 0-1 .8-1.6 1.8-1.6H17a3.5 3.5 0 0 0 3.5-3.5C20.5 6.6 16.8 3.5 12 3.5z"/><circle cx="7.8" cy="11" r="1"/><circle cx="10.5" cy="7.5" r="1"/><circle cx="15" cy="7.8" r="1"/>',
  data: '<ellipse cx="12" cy="6" rx="7" ry="2.8"/><path d="M5 6v6c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8V6M5 12v6c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8v-6"/>',
  info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.8v.2"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3.2 2"/>',
  cloud: '<path d="M7 18.5a4 4 0 0 1-.6-7.95A5.5 5.5 0 0 1 17 9.8a4.3 4.3 0 0 1 .4 8.7z"/>',
  calc: '<rect x="5" y="3" width="14" height="18" rx="3"/><path d="M8.5 7.5h7M8.5 12h.01M12 12h.01M15.5 12h.01M8.5 16h.01M12 16h.01M15.5 16h.01"/>',
  note: '<path d="M6 3.5h9l4 4V18a2.5 2.5 0 0 1-2.5 2.5h-10.5A2.5 2.5 0 0 1 3.5 18V6A2.5 2.5 0 0 1 6 3.5z" transform="translate(.5 0)"/><path d="M8 11.5h8M8 15h5"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4-4"/>',
  location: '<path d="M12 21s6.5-5.6 6.5-11a6.5 6.5 0 0 0-13 0c0 5.4 6.5 11 6.5 11z"/><circle cx="12" cy="10" r="2.3"/>',
  refresh: '<path d="M4 12a8 8 0 0 1 13.7-5.6L20 8.5M20 4v4.5h-4.5M20 12a8 8 0 0 1-13.7 5.6L4 15.5M4 20v-4.5h4.5"/>',
  copy: '<rect x="8.5" y="8.5" width="11" height="11" rx="2.5"/><path d="M15.5 8.5V6A2.5 2.5 0 0 0 13 3.5H6A2.5 2.5 0 0 0 3.5 6v7A2.5 2.5 0 0 0 6 15.5h2.5"/>',
  sliders: '<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>',
  logo: '<circle cx="12" cy="12" r="8.5"/><path d="m5.5 17 4-6 3 4 2-3 4 5"/>',
  move: '<path d="M12 3v18M3 12h18M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3"/>',
  download: '<path d="M12 4v11M7.5 11 12 15.5 16.5 11M5 19.5h14"/>',
  upload: '<path d="M12 15.5V4.5M7.5 9 12 4.5 16.5 9M5 19.5h14"/>',
  star: '<path d="m12 3.8 2.5 5.1 5.6.8-4 3.9.9 5.6-5-2.6-5 2.6.9-5.6-4-3.9 5.6-.8z"/>',
  globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.5 2.4 3.6 5.2 3.6 8.5S14.500 18.100 12 20.500C9.500 18.100 8.400 15.300 8.400 12S9.500 5.900 12 3.500z"/>'
};
const svg = (name, cls) => `<svg viewBox="0 0 24 24" class="ic ${cls || ""}" aria-hidden="true">${ICONS[name] || ""}</svg>`;
const icon = (name, cls) => { const t = document.createElement("template"); t.innerHTML = svg(name, cls); return t.content.firstChild; };

/* ---------- Contrôles ---------- */
const ui = {
  group(title, rows, footer) {
    return h("section", { class: "grp" },
      title ? h("h5", {}, title) : null,
      h("div", { class: "rows" }, rows),
      footer ? h("p", { class: "foot" }, footer) : null);
  },
  row({ icon: ic, color, label, sub, control, onClick, danger, chevron, stack }) {
    const lead = ic ? h("i", { class: "rico", style: color ? { background: color } : null, html: svg(ic) }) : null;
    const text = h("div", { class: "rtxt" }, h("b", {}, label), sub ? h("small", {}, sub) : null);
    const el = h(onClick ? "button" : "div", { class: "row" + (danger ? " danger" : "") + (stack ? " stack" : "") + (onClick ? " tap" : ""), type: onClick ? "button" : null, onClick },
      lead, text, control ? h("div", { class: "rctl" }, control) : null,
      chevron ? h("span", { class: "rchev", html: svg("chevron") }) : null);
    return el;
  },
  switch(get, set) {
    const input = h("input", { type: "checkbox", checked: !!get(), onChange: (e) => set(e.target.checked) });
    return h("label", { class: "swc" }, input, h("span"));
  },
  range({ min, max, step = 1, get, set, fmt, live }) {
    const out = h("output");
    const input = h("input", { type: "range", min, max, step });
    const paint = () => {
      const v = +input.value;
      input.style.setProperty("--p", ((v - min) / (max - min)) * 100 + "%");
      out.textContent = fmt ? fmt(v) : v;
    };
    input.value = get();
    paint();
    input.addEventListener("input", () => { paint(); set(+input.value, true); });
    input.addEventListener("change", () => set(+input.value, false));
    return h("div", { class: "rg" }, input, out);
  },
  segment(opts, get, set) {
    const thumb = h("i", { class: "thumb" });
    const wrap = h("div", { class: "seg", role: "tablist" }, thumb);
    const btns = opts.map((o) => {
      const b = h("button", { type: "button", role: "tab", class: "segb", onClick: () => { cur = o.v; set(o.v); paint(); } }, o.l);
      wrap.append(b);
      return b;
    });
    let cur = get();
    const paint = () => {
      const i = Math.max(0, opts.findIndex((o) => o.v === cur));
      btns.forEach((b, j) => b.classList.toggle("on", j === i));
      const b = btns[i];
      thumb.style.width = b.offsetWidth + "px";
      thumb.style.transform = `translateX(${b.offsetLeft}px)`;
    };
    new ResizeObserver(paint).observe(wrap);
    return wrap;
  },
  swatches(colors, get, set, custom) {
    const wrap = h("div", { class: "swatches" });
    const draw = () => {
      wrap.innerHTML = "";
      const cur = (get() || "").toLowerCase();
      for (const c of colors) {
        wrap.append(h("button", { type: "button", class: "sws" + (cur === c.toLowerCase() ? " on" : ""), style: { "--c": c }, "aria-label": c, onClick: () => { set(c); draw(); } }));
      }
      if (custom) {
        const isCustom = cur && !colors.some((c) => c.toLowerCase() === cur);
        const inp = h("input", { type: "color", value: /^#[0-9a-f]{6}$/i.test(cur) ? cur : "#ffffff", onInput: (e) => { set(e.target.value); }, onChange: draw });
        wrap.append(h("label", { class: "sws custom" + (isCustom ? " on" : ""), style: { "--c": isCustom ? cur : "transparent" }, title: "Couleur personnalisée" }, inp));
      }
    };
    draw();
    return wrap;
  },
  button(label, { kind = "soft", onClick, ic } = {}) {
    return h("button", { type: "button", class: "btn " + kind, onClick }, ic ? icon(ic) : null, label);
  }
};

/* ---------- Boîtes de dialogue ---------- */
function openDlg(d) {
  d.classList.remove("closing");
  if (!d.open) { d.showModal(); if (!d.contains(document.activeElement) || document.activeElement.classList.contains("xbtn")) { d.tabIndex = -1; d.focus({ preventScroll: true }); } }
}
function closeDlg(d) {
  if (!d.open || d.classList.contains("closing")) return;
  d.classList.add("closing");
  setTimeout(() => { d.close(); d.classList.remove("closing"); }, 190);
}
function wireDlg(d) {
  d.addEventListener("cancel", (e) => { e.preventDefault(); closeDlg(d); });
  d.addEventListener("mousedown", (e) => { if (e.target === d) closeDlg(d); });
}

let toastTimer, toastHide;
function toast(msg) {
  const t = $("toast");
  t.textContent = msg;
  clearTimeout(toastHide);
  // Popover : reste au-dessus des fenêtres modales (top layer)
  try { if (!t.matches(":popover-open")) t.showPopover(); } catch {}
  requestAnimationFrame(() => t.classList.add("show"));
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    t.classList.remove("show");
    toastHide = setTimeout(() => { try { t.hidePopover(); } catch {} }, 320);
  }, 2800);
}
function confirmBox(msg, okLabel, title, danger) {
  return new Promise((resolve) => {
    const d = $("dlgConfirm");
    $("cfTitle").textContent = title || "Confirmation";
    $("cfMsg").textContent = msg;
    const ok = $("cfOk");
    ok.textContent = okLabel || "Confirmer";
    ok.classList.toggle("danger", !!danger);
    let done = false;
    const end = (v) => { if (done) return; done = true; closeDlg(d); resolve(v); };
    ok.onclick = () => end(true);
    $("cfNo").onclick = () => end(false);
    d.oncancel = (e) => { e.preventDefault(); end(false); };
    openDlg(d);
  });
}
