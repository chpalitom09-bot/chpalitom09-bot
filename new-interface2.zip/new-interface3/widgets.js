/* ============ Widgets : registre + implémentations ============ */

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

/* ---------- Polices ---------- */
const FONTS = {
  system:   { n: "Système",   css: '"SF Pro Display","Segoe UI Variable Display","Segoe UI",system-ui,-apple-system,sans-serif', w: [100, 900], k: 1 },
  outfit:   { n: "Outfit",    css: '"NT Outfit",sans-serif', w: [100, 900], k: 1 },
  quicksand:{ n: "Quicksand", css: '"NT Quicksand",sans-serif', w: [300, 700], k: 1 },
  playfair: { n: "Playfair",  css: '"NT Playfair",Georgia,serif', w: [400, 900], k: 1 },
  mono:     { n: "JetBrains", css: '"NT Mono",ui-monospace,monospace', w: [100, 800], k: .9 },
  orbitron: { n: "Orbitron",  css: '"NT Orbitron",sans-serif', w: [400, 900], k: .82 },
  bebas:    { n: "Bebas",     css: '"NT Bebas",Impact,sans-serif', w: null, k: 1.2 },
  caveat:   { n: "Caveat",    css: '"NT Caveat",cursive', w: [400, 700], k: 1.3 }
};
const fontOf = (c) => FONTS[c.font] || FONTS.system;
const weightOf = (c) => { const f = fontOf(c); return f.w ? clamp(c.weight, f.w[0], f.w[1]) : 400; };

/* ---------- Météo : données ---------- */
const WX = {
  cache: {},
  TTL: 15 * 60 * 1000,
  key: (c) => `${(+c.lat).toFixed(2)},${(+c.lon).toFixed(2)}`,
  async get(city, force) {
    const k = WX.key(city), hit = WX.cache[k];
    if (hit && !force && Date.now() - hit.t < WX.TTL) return hit.data;
    try {
      const url = "https://api.open-meteo.com/v1/forecast?latitude=" + city.lat + "&longitude=" + city.lon +
        "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,is_day,wind_speed_10m" +
        "&hourly=temperature_2m,weather_code,is_day" +
        "&daily=weather_code,temperature_2m_max,temperature_2m_min" +
        "&timezone=auto&forecast_days=6&wind_speed_unit=kmh";
      const ctl = new AbortController();
      const to = setTimeout(() => ctl.abort(), 10000);
      const r = await fetch(url, { signal: ctl.signal });
      clearTimeout(to);
      if (!r.ok) throw new Error("http " + r.status);
      const data = WX.normalize(await r.json());
      WX.cache[k] = { t: Date.now(), data };
      try { chrome.storage.local.set({ wx: WX.cache }); } catch {}
      return data;
    } catch (e) {
      if (hit) return { ...hit.data, stale: true };
      throw e;
    }
  },
  normalize(j) {
    const cur = j.current, hr = j.hourly, dy = j.daily;
    const base = cur.time.slice(0, 13);
    let i0 = hr.time.findIndex((t) => t.slice(0, 13) >= base);
    if (i0 < 0) i0 = 0;
    const hours = [];
    for (let i = i0; i < Math.min(i0 + 12, hr.time.length); i++) {
      hours.push({ h: +hr.time[i].slice(11, 13), t: hr.temperature_2m[i], code: hr.weather_code[i], day: !!hr.is_day[i] });
    }
    const days = dy.time.map((d, i) => {
      const [y, m, dd] = d.split("-").map(Number);
      return { date: new Date(y, m - 1, dd), min: dy.temperature_2m_min[i], max: dy.temperature_2m_max[i], code: dy.weather_code[i] };
    });
    return {
      cur: { t: cur.temperature_2m, feel: cur.apparent_temperature, hum: cur.relative_humidity_2m, wind: cur.wind_speed_10m, code: cur.weather_code, day: !!cur.is_day },
      hours, days
    };
  },
  demo() {
    const now = new Date(), hours = [], codes = [2, 2, 1, 1, 3, 61, 3, 2, 1, 0, 0, 1];
    for (let i = 0; i < 12; i++) hours.push({ h: (now.getHours() + i) % 24, t: 17 + Math.sin(i / 3) * 4, code: codes[i], day: true });
    const dc = [2, 61, 3, 1, 0, 95], mx = [20, 17, 16, 19, 22, 18], mn = [11, 10, 9, 8, 12, 11];
    const days = dc.map((c, i) => ({ date: new Date(now.getFullYear(), now.getMonth(), now.getDate() + i), min: mn[i], max: mx[i], code: c }));
    return { cur: { t: 18, feel: 17, hum: 62, wind: 14, code: 2, day: true }, hours, days };
  }
};

/* ---------- Météo : icônes & libellés ---------- */
const CLOUD = '<path d="M18 50a9 9 0 0 1 1.5-17.8A14 14 0 0 1 46 30a10 10 0 0 1 2 20z"';
const RAYS = [...Array(8)].map((_, i) => { const a = i * Math.PI / 4, c = Math.cos(a), s = Math.sin(a); return `<path d="M${(32 + c * 19).toFixed(1)} ${(32 + s * 19).toFixed(1)}L${(32 + c * 25).toFixed(1)} ${(32 + s * 25).toFixed(1)}"/>`; }).join("");
const WI = {
  sun: `<svg viewBox="0 0 64 64"><g stroke="#ffc83d" stroke-width="3.6" stroke-linecap="round">${RAYS}</g><circle cx="32" cy="32" r="12.5" fill="url(#gSun)"/></svg>`,
  moon: `<svg viewBox="0 0 64 64"><circle cx="30" cy="34" r="19" fill="url(#gMoon)" mask="url(#mMoon)"/><circle cx="46" cy="14" r="1.6" fill="#fff" opacity=".9"/><circle cx="52" cy="26" r="1.1" fill="#fff" opacity=".7"/></svg>`,
  cloud: `<svg viewBox="0 0 64 64">${CLOUD} fill="url(#gCloud)"/></svg>`,
  dark: `<svg viewBox="0 0 64 64">${CLOUD} fill="url(#gCloudDark)"/></svg>`,
  partDay: `<svg viewBox="0 0 64 64"><g transform="translate(-6 -6) scale(.78)"><g stroke="#ffc83d" stroke-width="4" stroke-linecap="round">${RAYS}</g><circle cx="32" cy="32" r="12.5" fill="url(#gSun)"/></g><g transform="translate(5 5) scale(.88)">${CLOUD} fill="url(#gCloud)" stroke="rgba(120,135,160,.25)" stroke-width="1"/></g></svg>`,
  partNight: `<svg viewBox="0 0 64 64"><g transform="translate(-6 -8) scale(.8)"><circle cx="30" cy="34" r="19" fill="url(#gMoon)" mask="url(#mMoon)"/></g><g transform="translate(5 5) scale(.88)">${CLOUD} fill="url(#gCloud)"/></g></svg>`,
  rain: `<svg viewBox="0 0 64 64"><g transform="translate(0 -6)">${CLOUD} fill="url(#gCloudDark)"/></g><g stroke="#5ac8fa" stroke-width="3.4" stroke-linecap="round"><path d="M23 48l-2.5 8M33 48l-2.5 8M43 48l-2.5 8"/></g></svg>`,
  snow: `<svg viewBox="0 0 64 64"><g transform="translate(0 -6)">${CLOUD} fill="url(#gCloud)"/></g><g fill="#fff"><circle cx="22" cy="53" r="2.7"/><circle cx="32" cy="58" r="2.7"/><circle cx="42" cy="53" r="2.7"/></g></svg>`,
  storm: `<svg viewBox="0 0 64 64"><g transform="translate(0 -7)">${CLOUD} fill="url(#gCloudDark)"/></g><path d="M35 40l-9 13h6l-3 10 12-14h-7z" fill="url(#gBolt)"/></svg>`,
  fog: `<svg viewBox="0 0 64 64"><g transform="translate(0 -6)">${CLOUD} fill="url(#gCloud)"/></g><g stroke="#dfe5ef" stroke-width="3.2" stroke-linecap="round"><path d="M16 49h32M22 56h26"/></g></svg>`
};
function wmo(code, day = true) {
  const t = (label, kind, ic) => ({ label, kind, icon: WI[ic] });
  if (code === 0) return day ? t("Ensoleillé", "sun", "sun") : t("Ciel dégagé", "night", "moon");
  if (code === 1) return day ? t("Plutôt dégagé", "sun", "sun") : t("Plutôt dégagé", "night", "moon");
  if (code === 2) return day ? t("Éclaircies", "sun", "partDay") : t("Éclaircies", "night", "partNight");
  if (code === 3) return t("Couvert", "cloud", "cloud");
  if (code === 45 || code === 48) return t("Brouillard", "cloud", "fog");
  if (code >= 51 && code <= 57) return t("Bruine", "rain", "rain");
  if ((code >= 61 && code <= 67) || (code >= 80 && code <= 82)) return t(code >= 80 ? "Averses" : "Pluie", "rain", "rain");
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return t("Neige", "snow", "snow");
  if (code >= 95) return t("Orage", "storm", "storm");
  return t("Variable", "cloud", "cloud");
}

/* ---------- Horloge ---------- */
function dateText(fmt, d = new Date()) {
  const o = fmt === "short" ? { weekday: "short", day: "numeric", month: "short" } : fmt === "num" ? { day: "2-digit", month: "2-digit", year: "numeric" } : { weekday: "long", day: "numeric", month: "long" };
  return cap(d.toLocaleDateString("fr-FR", o));
}
function mountClock(host, c, ctx) {
  host.classList.add("w-clock");
  host.classList.toggle("card", !!c.card);
  host.style.setProperty("--col", c.color);
  let root, tick;
  const dateEl = h("div", { class: "cl-date" });
  const font = fontOf(c);
  if (c.style === "analog") {
    const S = c.asize;
    const ticks = [...Array(60)].map((_, i) => {
      const major = i % 5 === 0, a = i * Math.PI / 30, r1 = major ? 82 : 88, r2 = 93;
      if (c.dial === "minimal" && !(i % 15 === 0)) return "";
      if (c.dial === "numbers" && major) return "";
      return `<path d="M${(100 + Math.sin(a) * r1).toFixed(2)} ${(100 - Math.cos(a) * r1).toFixed(2)}L${(100 + Math.sin(a) * r2).toFixed(2)} ${(100 - Math.cos(a) * r2).toFixed(2)}" stroke="var(--col)" stroke-width="${major ? 3.4 : 1.2}" stroke-linecap="round" opacity="${major ? 1 : .55}"/>`;
    }).join("");
    const nums = c.dial === "numbers" ? [...Array(12)].map((_, i) => { const n = i + 1, a = n * Math.PI / 6; return `<text x="${(100 + Math.sin(a) * 72).toFixed(2)}" y="${(100 - Math.cos(a) * 72).toFixed(2)}" text-anchor="middle" dominant-baseline="central" fill="var(--col)" font-size="${22 * font.k}" font-family='${font.css.replace(/'/g, "")}' font-weight="${Math.max(weightOf(c), 300)}">${n}</text>`; }).join("") : "";
    const sec = c.secHand ? `<g class="hand s"><path d="M100 16V120" stroke="#ff9f0a" stroke-width="1.8" stroke-linecap="round"/><circle cx="100" cy="100" r="5.5" fill="#ff9f0a"/></g>` : "";
    root = h("div", { class: "cl an", style: { width: S + "px", height: S + "px" }, html:
      `<svg viewBox="0 0 200 200"><circle cx="100" cy="100" r="97" class="face"/>${ticks}${nums}` +
      `<g class="hand h"><rect x="96.6" y="50" width="6.8" height="58" rx="3.4" fill="var(--col)"/></g>` +
      `<g class="hand m"><rect x="97.6" y="26" width="4.8" height="84" rx="2.4" fill="var(--col)"/></g>${sec}` +
      `<circle cx="100" cy="100" r="3" fill="${c.secHand ? "#1c1c1e" : "var(--col)"}"/></svg>` });
    const H = root.querySelector(".h"), M = root.querySelector(".m"), Sx = root.querySelector(".s");
    let cyc = 0, lastS = null;
    tick = () => {
      const d = new Date(), s = d.getSeconds(), m = d.getMinutes() + s / 60, hr = (d.getHours() % 12) + m / 60;
      H.style.transform = `rotate(${hr * 30}deg)`;
      M.style.transform = `rotate(${m * 6}deg)`;
      if (Sx) {
        if (lastS === null) Sx.style.transition = "none"; else { Sx.style.transition = ""; if (s < lastS) cyc++; }
        lastS = s;
        Sx.style.transform = `rotate(${cyc * 360 + s * 6}deg)`;
      }
      if (c.showDate) dateEl.textContent = dateText(c.dateFmt, d);
    };
    dateEl.style.fontSize = clamp(S * .085, 13, 22) + "px";
  } else {
    const fs = c.size * font.k;
    root = h("div", { class: "cl dg", style: { fontFamily: font.css, fontWeight: weightOf(c), fontSize: fs + "px" } },
      h("div", { class: "cl-time" },
        h("span", { class: "hh" }), h("span", { class: "colon" + (c.blink ? " blink" : "") }, ":"), h("span", { class: "mm" }),
        c.seconds ? [h("span", { class: "colon sc" + (c.blink ? " blink" : "") }, ":"), h("span", { class: "ss" })] : null,
        !c.h24 ? h("span", { class: "ap" }) : null));
    const hh = root.querySelector(".hh"), mm = root.querySelector(".mm"), ss = root.querySelector(".ss"), ap = root.querySelector(".ap");
    const set = (el, v) => { if (el && el.textContent !== v) el.textContent = v; };
    dateEl.style.fontSize = clamp(c.size * .2, 13, 30) + "px";
    tick = () => {
      const d = new Date(); let H = d.getHours();
      if (!c.h24) { set(ap, H >= 12 ? "PM" : "AM"); H = H % 12 || 12; }
      set(hh, c.h24 ? String(H).padStart(2, "0") : String(H));
      set(mm, String(d.getMinutes()).padStart(2, "0"));
      set(ss, String(d.getSeconds()).padStart(2, "0"));
      if (c.showDate) set(dateEl, dateText(c.dateFmt, d));
    };
  }
  host.append(root);
  if (c.showDate) host.append(dateEl);
  tick();
  const iv = setInterval(tick, 1000);
  return () => clearInterval(iv);
}

/* ---------- Météo : widget ---------- */
function mountWeather(host, c, ctx) {
  host.classList.add("w-wx", "sz-" + c.size);
  let dead = false, timer;
  const T = (v) => Math.round(c.unit === "f" ? v * 9 / 5 + 32 : v) + "°";
  const city = c.city || { name: "Paris" };
  const draw = (d) => {
    const w = wmo(d.cur.code, d.cur.day);
    host.dataset.kind = c.bg === "dynamic" ? w.kind : "glass";
    const hi = d.days[0].max, lo = d.days[0].min;
    const head = `<div class="wx-main">
        <div class="wx-city">${esc(city.name)}${city.gps ? ' <i>' + svg("location") + "</i>" : ""}</div>
        <div class="wx-temp">${T(d.cur.t)}</div>
        <div class="wx-sub"><span>${w.label}</span><span>H:${T(hi)} B:${T(lo)}</span></div>
      </div><div class="wx-ico">${w.icon}</div>`;
    const hours = d.hours.slice(0, c.size === "m" ? 5 : 6).map((x, i) => {
      const wi = wmo(x.code, x.day);
      return `<div class="wx-h"><span>${i === 0 ? "Auj." : x.h + "h"}</span><div>${wi.icon}</div><b>${T(x.t)}</b></div>`;
    }).join("");
    const allMin = Math.min(...d.days.map((x) => x.min)), allMax = Math.max(...d.days.map((x) => x.max)), span = Math.max(1, allMax - allMin);
    const days = d.days.slice(0, 5).map((x, i) => {
      const wi = wmo(x.code, true), l = ((x.min - allMin) / span) * 100, r = ((x.max - allMin) / span) * 100;
      const name = i === 0 ? "Auj." : x.date.toLocaleDateString("fr-FR", { weekday: "short" }).replace(".", "");
      return `<div class="wx-d"><span>${name}</span><div>${wi.icon}</div><em>${T(x.min)}</em><div class="bar"><i style="left:${l}%;width:${Math.max(8, r - l)}%"></i></div><b>${T(x.max)}</b></div>`;
    }).join("");
    host.innerHTML = `<div class="wx wx-${c.size}"><div class="wx-head">${head}</div>` +
      (c.size === "m" ? `<div class="wx-hours">${hours}</div>` : "") +
      (c.size === "l" ? `<div class="wx-hours">${hours}</div><div class="wx-days">${days}</div>` : "") +
      (d.stale ? '<div class="wx-stale" title="Hors connexion">Hors ligne</div>' : "") + "</div>";
  };
  const state = (cls, title, text, btn, onBtn) => {
    host.dataset.kind = "glass";
    host.innerHTML = `<div class="wx wx-${c.size} wx-state ${cls}"><div class="wx-ico">${WI.partDay}</div><b>${title}</b><span>${text}</span>${btn ? `<button type="button" class="wx-btn">${btn}</button>` : ""}</div>`;
    const b = host.querySelector(".wx-btn");
    if (b) b.onclick = onBtn || (() => ctx.edit());
  };
  if (ctx.demo) { draw(WX.demo()); return () => {}; }
  if (!c.city) { state("empty", "Météo", "Choisissez une ville.", "Choisir une ville"); return () => {}; }
  host.dataset.kind = "glass";
  host.innerHTML = `<div class="wx wx-${c.size} wx-state loading"><div class="sk a"></div><div class="sk b"></div><div class="sk c"></div></div>`;
  const load = async (force) => {
    try { const d = await WX.get(c.city, force); if (!dead) draw(d); }
    catch { if (!dead && !host.querySelector(".wx-head")) state("err", "Indisponible", "Impossible de charger la météo.", "Réessayer", () => load(true)); }
  };
  load();
  timer = setInterval(() => load(), WX.TTL);
  return () => { dead = true; clearInterval(timer); };
}

/* ---------- Calculatrice ---------- */
function mountCalc(host, c, ctx) {
  host.classList.add("w-calc");
  host.style.setProperty("--op", c.accent);
  host.style.zoom = { sm: .85, md: 1, lg: 1.2 }[c.scale] || 1;
  let cur = "0", acc = null, op = null, fresh = true, last = null, err = false;
  const OPS = { "÷": "÷", "×": "×", "−": "−", "+": "+" };
  const compute = (a, b, o) => o === "+" ? a + b : o === "−" ? a - b : o === "×" ? a * b : b === 0 ? NaN : a / b;
  const str = (r) => {
    if (!isFinite(r)) return null;
    if (r !== 0 && (Math.abs(r) >= 1e12 || Math.abs(r) < 1e-9)) return r.toExponential(5).replace(/\.?0+e/, "e");
    return String(parseFloat(r.toPrecision(12)));
  };
  const fail = () => { err = true; cur = "Erreur"; acc = op = last = null; fresh = true; };
  const reset = () => { cur = "0"; acc = null; op = null; fresh = true; last = null; err = false; };
  const fmt = (s) => {
    if (s === "Erreur" || /e/.test(s)) return s.replace(".", ",");
    const neg = s.startsWith("-"), [i, f] = s.replace("-", "").split(".");
    return (neg ? "-" : "") + i.replace(/\B(?=(\d{3})+(?!\d))/g, "\u202f") + (f !== undefined ? "," + f : "");
  };
  const press = (k) => {
    if (err && k !== "AC" && k !== "C") reset();
    if (/^\d$/.test(k) || k === ".") {
      if (fresh) { cur = k === "." ? "0." : k; fresh = false; }
      else {
        if (k === "." && cur.includes(".")) return paint();
        if (cur.replace(/[-.]/g, "").length >= 10) return paint();
        cur = cur === "0" && k !== "." ? k : cur === "-0" && k !== "." ? "-" + k : cur + k;
      }
    } else if (k === "AC" || k === "C") {
      if (k === "C") { cur = "0"; fresh = true; } else reset();
    } else if (k === "±") {
      cur = cur.startsWith("-") ? cur.slice(1) : "-" + cur;
      if (fresh && op === null) fresh = false;
    } else if (k === "%") {
      let v = parseFloat(cur);
      v = acc !== null && (op === "+" || op === "−") ? acc * v / 100 : v / 100;
      cur = str(v) ?? "0"; fresh = false;
    } else if (OPS[k]) {
      if (op && !fresh) {
        const r = str(compute(acc, parseFloat(cur), op));
        if (r === null) { fail(); return paint(); }
        acc = parseFloat(r); cur = r;
      } else acc = parseFloat(cur);
      op = k; fresh = true; last = null;
    } else if (k === "=") {
      if (op) {
        const b = parseFloat(cur), r = str(compute(acc, b, op));
        if (r === null) { fail(); return paint(); }
        last = { op, b }; cur = r; acc = null; op = null; fresh = true;
      } else if (last) {
        const r = str(compute(parseFloat(cur), last.b, last.op));
        if (r === null) { fail(); return paint(); }
        cur = r; fresh = true;
      }
    } else if (k === "⌫") {
      if (!fresh && cur.length > 1 && !(cur.length === 2 && cur.startsWith("-"))) cur = cur.slice(0, -1); else if (!fresh) cur = "0";
    }
    paint();
  };
  const display = h("div", { class: "cc-disp" }, h("span"));
  const layout = [["AC", "±", "%", "÷"], ["7", "8", "9", "×"], ["4", "5", "6", "−"], ["1", "2", "3", "+"], ["0", ",", "="]];
  const keys = {};
  const pad = h("div", { class: "cc-pad" }, layout.flat().map((k) => {
    const kind = OPS[k] || k === "=" ? "op" : ["AC", "±", "%"].includes(k) ? "fn" : "num";
    const b = h("button", { type: "button", class: "ck " + kind + (k === "0" ? " zero" : ""), "data-k": k, tabindex: "-1",
      onClick: () => { if (!ctx.demo) press(k === "," ? "." : k); } }, k);
    keys[k === "," ? "." : k] = b;
    return b;
  }));
  const paint = () => {
    const s = fmt(cur), sp = display.firstChild;
    sp.textContent = s;
    sp.style.fontSize = s.length <= 7 ? "42px" : s.length <= 9 ? "34px" : s.length <= 11 ? "28px" : "23px";
    keys.AC.textContent = cur !== "0" && !err && !fresh ? "C" : "AC";
    keys.AC.dataset.k = keys.AC.textContent;
    for (const o of Object.keys(OPS)) keys[o].classList.toggle("act", op === o && fresh);
  };
  host.append(display, pad);
  paint();
  host.tabIndex = -1;
  if (ctx.demo) return () => {};
  const onKey = (e) => {
    if (document.body.classList.contains("editing") || document.querySelector("dialog[open]")) return;
    const t = e.target;
    if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable)) return;
    if (!(host.matches(":hover") || host.contains(document.activeElement)) || e.ctrlKey || e.metaKey || e.altKey) return;
    let k = e.key;
    const map = { "*": "×", "/": "÷", "-": "−", ",": ".", Enter: "=", Escape: "AC", Delete: "AC", Backspace: "⌫" };
    k = map[k] || k;
    if (!(/^\d$/.test(k) || [".", "+", "−", "×", "÷", "=", "%", "AC", "⌫"].includes(k))) return;
    e.preventDefault();
    press(k === "AC" && keys.AC.textContent === "C" ? "C" : k);
    const b = keys[k === "⌫" ? "AC" : k];
    if (b && k !== "⌫") { b.classList.add("hit"); setTimeout(() => b.classList.remove("hit"), 120); }
  };
  document.addEventListener("keydown", onKey);
  return () => document.removeEventListener("keydown", onKey);
}

/* ---------- Notes ---------- */
function mountNotes(host, c, ctx) {
  host.classList.add("w-notes", "sz-" + c.size, "tint-" + c.tint);
  const ta = h("textarea", { placeholder: "Écrivez ici…", spellcheck: "false", maxlength: 4000, tabindex: ctx.demo ? "-1" : null });
  ta.value = c.text || "";
  if (ctx.demo) ta.value = "Réunion 15h\nAcheter du pain\nAppeler Léa";
  ta.addEventListener("input", () => ctx.patch({ text: ta.value }));
  host.append(h("div", { class: "nt-head", html: svg("note") + "<span>Notes</span>" }), ta);
  return () => {};
}

/* ---------- Recherche ---------- */
function mountSearch(host, c, ctx) {
  host.classList.add("w-search");
  host.style.setProperty("--sw", c.width + "px");
  const input = h("input", { type: "text", placeholder: "Rechercher ou saisir une adresse", autocomplete: "off", tabindex: ctx.demo ? "-1" : null });
  input.addEventListener("keydown", (e) => { if (e.key === "Enter" && input.value.trim() && !ctx.demo) doSearch(input.value.trim()); });
  host.append(h("div", { html: svg("search", "si") }).firstChild, input);
  return () => {};
}

/* ---------- Logo ---------- */
function mountLogo(host, c, ctx) {
  host.classList.add("w-logo");
  host.style.setProperty("--ls", c.size + "px");
  const box = h("div", { class: "logo" });
  box.append($("logoTpl").content.firstElementChild.cloneNode(true));
  const wheel = box.querySelector(".wheel");
  const spin = () => { if (state.settings.anim && !box.classList.contains("spin")) box.classList.add("spin"); };
  box.addEventListener("mouseenter", spin);
  box.addEventListener("click", spin);
  wheel.addEventListener("animationend", (e) => { if (e.target === wheel) box.classList.remove("spin"); });
  host.append(box);
  return () => {};
}

/* ---------- Registre ---------- */
const DATE_OPTS = [{ v: "long", l: "Complète" }, { v: "short", l: "Courte" }, { v: "num", l: "Numérique" }];
const WHITE_SET = ["#ffffff", "#ffd60a", "#ff9f0a", "#ff6482", "#30d158", "#64d2ff", "#bf5af2"];
const WIDGETS = {
  clock: {
    name: "Horloge", cat: "Essentiels", ic: "clock", color: "linear-gradient(135deg,#ff9f0a,#ff6a00)",
    desc: "Numérique ou analogique, avec la police, la taille et la couleur de votre choix.",
    defaults: { style: "digital", font: "system", size: 80, asize: 180, weight: 200, h24: true, seconds: false, blink: true, showDate: true, dateFmt: "long", color: "#ffffff", card: false, dial: "ticks", secHand: true },
    sample: { size: 56, asize: 120, font: "outfit", weight: 300 },
    mount: mountClock,
    sub: (c) => c.style === "analog" ? `Analogique · ${c.asize} px` : `${fontOf(c).n} · ${c.size} px`,
    fields: (c) => [
      { sec: "Style", k: "style", t: "segment", l: "Type", opts: [{ v: "digital", l: "Numérique" }, { v: "analog", l: "Analogique" }] },
      c.style === "digital" || c.dial === "numbers" ? { k: "font", t: "fonts", l: "Police" } : null,
      c.style === "digital" ? { k: "size", t: "range", l: "Taille", min: 32, max: 220, step: 2, fmt: (v) => v + " px" } : { k: "asize", t: "range", l: "Taille", min: 110, max: 360, step: 5, fmt: (v) => v + " px" },
      (c.style === "digital" || c.dial === "numbers") && fontOf(c).w ? { k: "weight", t: "range", l: "Graisse", min: fontOf(c).w[0], max: fontOf(c).w[1], step: 100, fmt: (v) => v } : null,
      c.style === "analog" ? { k: "dial", t: "segment", l: "Cadran", opts: [{ v: "ticks", l: "Traits" }, { v: "numbers", l: "Chiffres" }, { v: "minimal", l: "Minimal" }] } : null,
      c.style === "analog" ? { k: "secHand", t: "switch", l: "Trotteuse" } : null,
      c.style === "digital" ? { sec: "Affichage", k: "h24", t: "segment", l: "Format", opts: [{ v: true, l: "24 h" }, { v: false, l: "12 h" }] } : null,
      c.style === "digital" ? { k: "seconds", t: "switch", l: "Afficher les secondes" } : null,
      c.style === "digital" ? { k: "blink", t: "switch", l: "Deux-points clignotants" } : null,
      { sec: "Date", k: "showDate", t: "switch", l: "Afficher la date" },
      c.showDate ? { k: "dateFmt", t: "segment", l: "Format de la date", opts: DATE_OPTS } : null,
      { sec: "Apparence", k: "color", t: "color", l: "Couleur", set: WHITE_SET },
      { k: "card", t: "switch", l: "Fond en verre" }
    ].filter(Boolean),
    onChange(c, k) { if (k === "font") { const f = fontOf(c); if (f.w) c.weight = clamp(c.weight, f.w[0], f.w[1]); } }
  },
  weather: {
    name: "Météo", cat: "Essentiels", ic: "cloud", color: "linear-gradient(135deg,#4facfe,#0a84ff)",
    desc: "Prévisions en direct avec Open-Meteo : gratuit, sans clé API ni compte.",
    defaults: { city: null, unit: "c", size: "m", bg: "dynamic" },
    sample: { size: "m" },
    mount: mountWeather,
    sub: (c) => (c.city ? c.city.name : "Aucune ville") + " · " + { s: "Petit", m: "Moyen", l: "Grand" }[c.size],
    fields: () => [
      { sec: "Lieu", k: "city", t: "city", l: "Ville" },
      { sec: "Affichage", k: "size", t: "segment", l: "Taille", opts: [{ v: "s", l: "Petit" }, { v: "m", l: "Moyen" }, { v: "l", l: "Grand" }] },
      { k: "unit", t: "segment", l: "Unité", opts: [{ v: "c", l: "°C" }, { v: "f", l: "°F" }] },
      { k: "bg", t: "segment", l: "Fond", opts: [{ v: "dynamic", l: "Dynamique" }, { v: "glass", l: "Verre" }] }
    ]
  },
  calc: {
    name: "Calculatrice", cat: "Essentiels", ic: "calc", color: "linear-gradient(135deg,#5b5b60,#2c2c2e)",
    desc: "Les quatre opérations, pourcentages, et saisie au clavier en la survolant.",
    defaults: { scale: "md", accent: "#ff9f0a" },
    sample: {},
    mount: mountCalc,
    sub: (c) => ({ sm: "Petite", md: "Moyenne", lg: "Grande" }[c.scale]),
    fields: () => [
      { sec: "Affichage", k: "scale", t: "segment", l: "Taille", opts: [{ v: "sm", l: "Petite" }, { v: "md", l: "Moyenne" }, { v: "lg", l: "Grande" }] },
      { k: "accent", t: "color", l: "Couleur des opérateurs", set: ["#ff9f0a", "#0a84ff", "#30d158", "#bf5af2", "#ff375f"] }
    ]
  },
  notes: {
    name: "Notes", cat: "Essentiels", ic: "note", color: "linear-gradient(135deg,#ffd60a,#ff9f0a)",
    desc: "Un bloc-notes toujours sous la main, enregistré automatiquement.",
    defaults: { text: "", size: "md", tint: "yellow" },
    sample: {},
    mount: mountNotes,
    sub: (c) => (c.text || "").trim().split("\n")[0].slice(0, 32) || "Vide",
    fields: () => [
      { sec: "Affichage", k: "size", t: "segment", l: "Taille", opts: [{ v: "sm", l: "Petit" }, { v: "md", l: "Moyen" }, { v: "lg", l: "Grand" }] },
      { k: "tint", t: "segment", l: "Teinte", opts: [{ v: "yellow", l: "Jaune" }, { v: "mint", l: "Menthe" }, { v: "rose", l: "Rose" }, { v: "glass", l: "Verre" }] }
    ]
  },
  search: {
    name: "Recherche", cat: "Interface", ic: "search", color: "linear-gradient(135deg,#8e8e93,#636366)", single: true,
    desc: "Barre de recherche et de saisie d'adresse.",
    defaults: { width: 540 },
    sample: { width: 300 },
    mount: mountSearch,
    sub: (c) => `Largeur ${c.width} px`,
    fields: () => [{ sec: "Affichage", k: "width", t: "range", l: "Largeur", min: 280, max: 800, step: 10, fmt: (v) => v + " px" }]
  },
  logo: {
    name: "Logo", cat: "Interface", ic: "logo", color: "linear-gradient(135deg,#bf5af2,#5e5ce6)", single: true,
    desc: "Le logo animé de votre page d'accueil.",
    defaults: { size: 64 },
    sample: { size: 64 },
    mount: mountLogo,
    sub: (c) => `${c.size} px`,
    fields: () => [{ sec: "Affichage", k: "size", t: "range", l: "Taille", min: 32, max: 140, step: 2, fmt: (v) => v + " px" }]
  }
};
const WIDGET_ORDER = ["clock", "weather", "calc", "notes", "search", "logo"];
