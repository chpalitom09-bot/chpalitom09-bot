/* ============ New Interface — cœur de l'application ============ */
const clone = (o) => structuredClone(o);

const DEFAULT_SETTINGS = {
  blur: 0, dim: 25, size: 64, labels: true, bgUrl: "", anim: true, particles: false, parallax: true,
  accent: "#0a84ff", gblur: 18, galpha: 50
};
const defaultWidgets = () => [
  { id: "w_logo", type: "logo", x: 50, y: 9, cfg: { ...WIDGETS.logo.defaults } },
  { id: "w_clock", type: "clock", x: 50, y: 22, cfg: { ...WIDGETS.clock.defaults } },
  { id: "w_search", type: "search", x: 50, y: 37, cfg: { ...WIDGETS.search.defaults } }
];
const DEFAULTS = {
  shortcuts: [
    { id: "d1", title: "YouTube", url: "https://www.youtube.com", x: 30, y: 58 },
    { id: "d2", title: "GitHub", url: "https://github.com", x: 42, y: 58 },
    { id: "d3", title: "Gmail", url: "https://mail.google.com", x: 54, y: 58 },
    { id: "d4", title: "Kaggle", url: "https://www.kaggle.com", x: 66, y: 58 }
  ],
  settings: DEFAULT_SETTINGS,
  bg: "",
  v: 3
};
let state = { ...clone(DEFAULTS), widgets: defaultWidgets() };
let editing = false, editingId = null, enterAnim = true, lastAddedId = null;

/* ---------- Stockage & migration ---------- */
function normalizeState(raw) {
  const old = raw.settings || {};
  const out = { ...clone(DEFAULTS), ...raw, settings: { ...DEFAULT_SETTINGS, ...old } };
  if (!Array.isArray(raw.widgets)) {
    // Anciennes versions : logo / horloge / recherche étaient de simples interrupteurs
    out.widgets = defaultWidgets().filter((w) => ({ logo: old.logo, clock: old.clock, search: old.search })[w.type] !== false);
  }
  for (const k of ["logo", "clock", "search"]) delete out.settings[k];
  out.widgets = out.widgets.filter((w) => WIDGETS[w.type]).map((w) => ({
    id: w.id || "w" + Math.random().toString(36).slice(2, 8), type: w.type,
    x: clamp(+w.x || 50, 2, 98), y: clamp(+w.y || 50, 3, 97), cfg: { ...WIDGETS[w.type].defaults, ...(w.cfg || {}) }
  }));
  out.v = 3;
  return out;
}
async function load() {
  const data = await chrome.storage.local.get(["nt", "wx"]);
  if (data.wx) WX.cache = data.wx;
  state = data.nt ? normalizeState(data.nt) : { ...clone(DEFAULTS), widgets: defaultWidgets() };
  if (data.nt && (!data.nt.v || data.nt.v < 3)) save();
}
let saveTimer;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => chrome.storage.local.set({ nt: state }), 150);
}

/* ---------- Utilitaires ---------- */
function normUrl(u) { u = u.trim(); if (!u) return ""; return /^[a-z][a-z0-9+.-]*:/i.test(u) ? u : "https://" + u; }
function hostKey(u) { try { return new URL(u).hostname.replace(/^www\./, ""); } catch { return ""; } }
function favicon(url) {
  const f = new URL(chrome.runtime.getURL("/_favicon/"));
  f.searchParams.set("pageUrl", url);
  f.searchParams.set("size", "64");
  return f.toString();
}
function freeSlot() {
  const xs = [20, 32, 44, 56, 68, 80], ys = [58, 73, 88];
  for (const y of ys) for (const x of xs) {
    if (!state.shortcuts.some((s) => Math.abs(s.x - x) < 6 && Math.abs(s.y - y) < 7)) return { x, y };
  }
  const n = state.shortcuts.length;
  return { x: 20 + (n % 7) * 10, y: 58 + (Math.floor(n / 7) % 3) * 14 };
}
function doSearch(q) {
  if (/^https?:\/\/\S+$/i.test(q) || /^[\w-]+(\.[\w-]+)+(\/\S*)?$/.test(q)) { location.href = normUrl(q); return; }
  try { chrome.search.query({ text: q, disposition: "CURRENT_TAB" }); }
  catch { location.href = "https://www.google.com/search?q=" + encodeURIComponent(q); }
}

/* ---------- Apparence globale ---------- */
function applyBody() {
  const s = state.settings, r = document.documentElement.style;
  r.setProperty("--accent", s.accent);
  r.setProperty("--gblur", s.gblur + "px");
  r.setProperty("--ga", (0.02 + (s.galpha / 100) * 0.2).toFixed(3));
  document.body.classList.toggle("nolabels", !s.labels);
}
function renderBg() {
  const bg = state.bg || state.settings.bgUrl;
  $("bg").style.backgroundImage = bg ? `url("${bg}")` : "";
  $("bg").classList.toggle("nobg", !bg);
  document.body.classList.toggle("noanim", !state.settings.anim);
  applyFx();
  $("bg").style.filter = `blur(${state.settings.blur}px)`;
  $("dim").style.opacity = state.settings.dim / 100;
}

/* ---------- Widgets : cycle de vie ---------- */
const instances = new Map();

function mountWidget(w, body) {
  const ctx = { id: w.id, demo: false, patch: (p) => { Object.assign(w.cfg, p); save(); }, edit: () => openWidgetEditor(w.id) };
  return WIDGETS[w.type].mount(body, w.cfg, ctx);
}
function createWidgetEl(w, animate, index = 0) {
  const el = h("div", { class: "widget wt-" + w.type + (animate ? " enter" : ""), "data-id": w.id, style: { left: w.x + "%", top: w.y + "%", "--i": index } });
  const body = h("div", { class: "w-body" });
  const rm = h("button", { type: "button", class: "wbadge rm", title: "Retirer", "aria-label": "Retirer le widget", html: svg("minus"), onClick: (e) => { e.preventDefault(); e.stopPropagation(); removeWidget(w.id); } });
  const ed = h("button", { type: "button", class: "wbadge ed", title: "Régler", "aria-label": "Régler le widget", html: svg("sliders"), onClick: (e) => { e.preventDefault(); e.stopPropagation(); openWidgetEditor(w.id); } });
  el.append(body, rm, ed);
  el.addEventListener("pointerdown", (e) => startDrag(e, el, w));
  el.addEventListener("contextmenu", (e) => {
    e.preventDefault();
    const def = WIDGETS[w.type];
    showCtx(e.clientX, e.clientY, [
      { l: "Régler le widget…", ic: "sliders", fn: () => openWidgetEditor(w.id) },
      !def.single ? { l: "Dupliquer", ic: "copy", fn: () => duplicateWidget(w.id) } : null,
      "-",
      { l: "Retirer", ic: "trash", danger: true, fn: () => removeWidget(w.id) }
    ].filter(Boolean));
  });
  $("widgets").append(el);
  instances.set(w.id, { el, body, cleanup: mountWidget(w, body) });
  return el;
}
function renderWidgets() {
  for (const i of instances.values()) { if (i.cleanup) i.cleanup(); }
  instances.clear();
  $("widgets").innerHTML = "";
  state.widgets.forEach((w, i) => createWidgetEl(w, enterAnim, i));
}
function refreshWidget(id) {
  const w = state.widgets.find((x) => x.id === id), inst = instances.get(id);
  if (!w || !inst) return;
  if (inst.cleanup) inst.cleanup();
  inst.body.className = "w-body"; inst.body.style.cssText = ""; inst.body.innerHTML = "";
  inst.cleanup = mountWidget(w, inst.body);
}
function placeWidget(w) {
  const el = instances.get(w.id).el;
  const W = el.offsetWidth, H = el.offsetHeight;
  const others = [...document.querySelectorAll(".widget, .tile")].filter((n) => n !== el).map((n) => n.getBoundingClientRect());
  const pref = { logo: [50, 9], clock: [50, 22], search: [50, 37] }[w.type];
  const cands = pref ? [pref] : [];
  for (const y of [42, 72, 28, 88]) for (const x of [80, 20, 65, 35, 50]) cands.push([x, y]);
  const m = 14;
  let best = null;
  for (const [x, y] of cands) {
    const cx = (x / 100) * innerWidth, cy = (y / 100) * innerHeight;
    const l = cx - W / 2, r = cx + W / 2, t = cy - H / 2, b = cy + H / 2;
    if (l < m || t < m || r > innerWidth - m || b > innerHeight - m) continue;
    let over = 0;
    for (const o of others) {
      const ow = Math.min(r + m, o.right) - Math.max(l - m, o.left), oh = Math.min(b + m, o.bottom) - Math.max(t - m, o.top);
      if (ow > 0 && oh > 0) over += ow * oh;
    }
    if (over === 0) { best = [x, y]; break; }
    if (!best || over < best.over) { best = [x, y]; best.over = over; }
  }
  const [bx, by] = best || [50, 45];
  w.x = bx; w.y = by; el.style.left = bx + "%"; el.style.top = by + "%";
}
function addWidget(type, cfg) {
  const def = WIDGETS[type];
  if (def.single && state.widgets.some((w) => w.type === type)) { toast(def.name + " est déjà affiché"); return null; }
  const w = { id: "w" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), type, x: 50, y: 45, cfg: { ...def.defaults, ...(cfg || {}) } };
  state.widgets.push(w);
  createWidgetEl(w, true);
  placeWidget(w);
  save();
  toast(def.name + " ajouté");
  if (type === "weather") setTimeout(() => openWidgetEditor(w.id), 420);
  return w;
}
function duplicateWidget(id) {
  const src = state.widgets.find((w) => w.id === id);
  if (!src) return;
  const w = addWidget(src.type, clone(src.cfg));
  if (w) toast(WIDGETS[src.type].name + " dupliqué");
}
function removeWidget(id) {
  const inst = instances.get(id);
  state.widgets = state.widgets.filter((w) => w.id !== id);
  if (inst) {
    if (inst.cleanup) inst.cleanup();
    instances.delete(id);
    inst.el.classList.add("leaving");
    setTimeout(() => inst.el.remove(), 220);
  }
  save();
}
function resetWidgets() {
  state.widgets = defaultWidgets();
  enterAnim = true; renderWidgets(); save();
  setTimeout(() => { enterAnim = false; }, 1500);
  toast("Disposition d'origine rétablie");
}
function resetAll() {
  state = { ...clone(DEFAULTS), widgets: defaultWidgets() };
  enterAnim = true; renderAll(); save();
  setTimeout(() => { enterAnim = false; }, 1500);
  toast("Configuration réinitialisée");
}

/* ---------- Raccourcis ---------- */
function renderTiles() {
  const box = $("tiles");
  box.innerHTML = "";
  box.style.setProperty("--size", state.settings.size + "px");
  for (const [i, s] of state.shortcuts.entries()) {
    const a = document.createElement("a");
    a.className = "tile" + (enterAnim || s.id === lastAddedId ? " enter" : "");
    a.style.setProperty("--i", i);
    a.href = s.url;
    a.dataset.id = s.id;
    a.style.left = s.x + "%";
    a.style.top = s.y + "%";
    a.style.setProperty("--size", state.settings.size + "px");

    const ico = document.createElement("div");
    ico.className = "ico";
    const img = document.createElement("img");
    img.src = favicon(s.url);
    img.draggable = false;
    img.onerror = () => { ico.innerHTML = ""; const b = document.createElement("b"); b.textContent = (s.title[0] || "?").toUpperCase(); ico.appendChild(b); };
    ico.appendChild(img);

    const label = document.createElement("span");
    label.textContent = s.title;

    const x = h("button", { type: "button", class: "wbadge rm", title: "Supprimer", html: svg("minus"), onClick: (e) => { e.preventDefault(); e.stopPropagation(); state.shortcuts = state.shortcuts.filter((t) => t.id !== s.id); save(); renderTiles(); } });
    const ed = h("button", { type: "button", class: "wbadge ed", title: "Modifier", html: svg("edit"), onClick: (e) => { e.preventDefault(); e.stopPropagation(); openShortcutDialog(s.id); } });

    a.append(ico, label, x, ed);
    a.addEventListener("click", (e) => { if (editing) e.preventDefault(); });
    a.addEventListener("pointerdown", (e) => startDrag(e, a, s));
    box.appendChild(a);
  }
}

function startDrag(e, el, item) {
  if (!editing || e.button > 0 || e.target.closest("button")) return;
  e.preventDefault();
  el.setPointerCapture(e.pointerId);
  el.classList.add("drag");
  const r = el.getBoundingClientRect();
  const offX = e.clientX - (r.left + r.width / 2), offY = e.clientY - (r.top + r.height / 2);
  const guide = $("guide");
  const move = (ev) => {
    let x = clamp(((ev.clientX - offX) / innerWidth) * 100, 2, 98);
    const y = clamp(((ev.clientY - offY) / innerHeight) * 100, 3, 97);
    const snap = Math.abs(x - 50) < 1.1;
    if (snap) x = 50;
    guide.classList.toggle("on", snap);
    item.x = x; item.y = y;
    el.style.left = x + "%";
    el.style.top = y + "%";
  };
  const up = () => {
    el.classList.remove("drag");
    guide.classList.remove("on");
    el.removeEventListener("pointermove", move);
    el.removeEventListener("pointerup", up);
    el.removeEventListener("pointercancel", up);
    save();
  };
  el.addEventListener("pointermove", move);
  el.addEventListener("pointerup", up);
  el.addEventListener("pointercancel", up);
}

function openShortcutDialog(id) {
  editingId = id || null;
  const s = state.shortcuts.find((t) => t.id === id);
  $("dlgShortcutTitle").textContent = s ? "Modifier le raccourci" : "Nouveau raccourci";
  $("scTitle").value = s ? s.title : "";
  $("scUrl").value = s ? s.url : "";
  openDlg($("dlgShortcut"));
  $("scTitle").focus();
}
$("scCancel").onclick = () => closeDlg($("dlgShortcut"));
$("scSave").onclick = () => {
  const url = normUrl($("scUrl").value);
  if (!url) return;
  let title = $("scTitle").value.trim();
  if (!title) title = hostKey(url) || url;
  if (editingId) {
    const s = state.shortcuts.find((t) => t.id === editingId);
    s.title = title; s.url = url;
    lastAddedId = null;
  } else {
    const p = freeSlot();
    const id = "s" + Date.now();
    state.shortcuts.push({ id, title, url, x: p.x, y: p.y });
    lastAddedId = id;
  }
  save(); renderTiles(); lastAddedId = null;
  closeDlg($("dlgShortcut"));
  if ($("dlgSettings").open) renderSettings();
};
$("scUrl").addEventListener("keydown", (e) => { if (e.key === "Enter") $("scSave").click(); });

async function importTopSites() {
  if (!chrome.topSites) { toast("Rechargez l'extension pour activer cette fonction."); return; }
  let sites = [];
  try { sites = await chrome.topSites.get(); } catch { toast("Impossible de lire les sites les plus visités."); return; }
  const known = new Set(state.shortcuts.map((s) => hostKey(s.url)));
  let added = 0;
  for (const t of sites) {
    const k = hostKey(t.url);
    if (!k || known.has(k)) continue;
    known.add(k);
    const p = freeSlot();
    const title = ((t.title || "").split(/\s[-|\u2013\u2014\u00b7]\s/)[0].trim().slice(0, 24)) || k;
    state.shortcuts.push({ id: "t" + Date.now() + "_" + added, title, url: t.url, x: p.x, y: p.y });
    added++;
  }
  if (added) { enterAnim = true; save(); renderTiles(); setTimeout(() => { enterAnim = false; }, 1500); if ($("dlgSettings").open) renderSettings(); }
  toast(added ? `${added} raccourci${added > 1 ? "s" : ""} Chrome ajouté${added > 1 ? "s" : ""}` : "Vos raccourcis Chrome sont déjà tous présents");
}
async function restoreDefaults() {
  const ok = await confirmBox("Les raccourcis actuels seront remplacés par la sélection d'origine (YouTube, GitHub, Gmail, Kaggle).", "Restaurer", "Restaurer les raccourcis", true);
  if (!ok) return;
  state.shortcuts = clone(DEFAULTS.shortcuts);
  enterAnim = true; save(); renderTiles();
  setTimeout(() => { enterAnim = false; }, 1500);
  if ($("dlgSettings").open) renderSettings();
  toast("Raccourcis par défaut restaurés");
}

/* ---------- Menu, mode édition, menu contextuel ---------- */
function setMenu(open) {
  $("dock").classList.toggle("open", open);
  $("menuBtn").setAttribute("aria-expanded", open);
}
$("menuBtn").onclick = (e) => { e.stopPropagation(); hideCtx(); setMenu(!$("dock").classList.contains("open")); };
document.addEventListener("click", (e) => { if (!e.target.closest("#dock")) setMenu(false); if (!e.target.closest("#ctx")) hideCtx(); });
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (document.querySelector("dialog[open]")) return;
  setMenu(false); hideCtx();
  if (editing) setEditing(false);
});
addEventListener("scroll", hideCtx, true);

function setEditing(v) {
  editing = v;
  document.body.classList.toggle("editing", v);
  $("miEditLabel").textContent = v ? "Terminer la modification" : "Modifier l'écran";
}
function showCtx(x, y, items) {
  const c = $("ctx");
  c.innerHTML = "";
  for (const it of items) {
    c.append(it === "-" ? h("div", { class: "msep" }) :
      h("button", { type: "button", class: "mi" + (it.danger ? " danger" : ""), role: "menuitem", onClick: () => { hideCtx(); it.fn(); } }, icon(it.ic), h("span", {}, h("b", {}, it.l))));
  }
  setMenu(false);
  c.classList.add("open");
  const r = c.getBoundingClientRect();
  c.style.left = Math.min(x, innerWidth - r.width - 10) + "px";
  c.style.top = Math.min(y, innerHeight - r.height - 10) + "px";
}
function hideCtx() { $("ctx").classList.remove("open"); }

$("miWidget").onclick = () => { setMenu(false); openGallery(); };
$("miAdd").onclick = () => { setMenu(false); openShortcutDialog(); };
$("miEdit").onclick = () => { setMenu(false); setEditing(!editing); };
$("miSettings").onclick = () => { setMenu(false); openSettings(); };
$("hintWidget").onclick = () => openGallery();
$("hintShortcut").onclick = () => openShortcutDialog();
$("hintDone").onclick = () => setEditing(false);

/* ---------- Import / export ---------- */
function exportConfig() {
  const blob = new Blob([JSON.stringify({ v: 3, shortcuts: state.shortcuts, widgets: state.widgets, settings: state.settings }, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = "nouvel-onglet-config.json"; a.click();
  toast("Configuration exportée");
}
$("importFile").onchange = async (e) => {
  try {
    const d = JSON.parse(await e.target.files[0].text());
    const next = normalizeState({ ...state, ...d, bg: state.bg, settings: { ...state.settings, ...(d.settings || {}) } });
    if (!Array.isArray(d.shortcuts)) next.shortcuts = state.shortcuts;
    state = next;
    save(); renderAll();
    if ($("dlgSettings").open) renderSettings();
    toast("Configuration importée");
  } catch { toast("Fichier invalide."); }
  e.target.value = "";
};

/* ---------- Fond d'écran : import ---------- */
$("bgFile").onchange = (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const img = new Image();
  img.onload = () => {
    const max = 2560, k = Math.min(1, max / Math.max(img.width, img.height));
    const c = document.createElement("canvas");
    c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
    c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    state.bg = c.toDataURL("image/jpeg", 0.88);
    state.settings.bgUrl = "";
    URL.revokeObjectURL(img.src);
    renderBg(); save();
    if ($("dlgSettings").open) renderSettings();
  };
  img.src = URL.createObjectURL(file);
  e.target.value = "";
};

/* ---------- Particules, parallaxe, inclinaison ---------- */
const fx = $("fx"), ctx2d = fx.getContext("2d");
let particles = [], fxRunning = false;
function sizeFx() { fx.width = innerWidth; fx.height = innerHeight; }
function initParticles() {
  particles = Array.from({ length: 55 }, () => ({
    x: Math.random() * fx.width, y: Math.random() * fx.height,
    r: Math.random() * 2.4 + .6, vx: (Math.random() - .5) * .25, vy: -(Math.random() * .35 + .08),
    a: Math.random() * .4 + .1, p: Math.random() * 6.28
  }));
}
function fxLoop() {
  if (!(state.settings.anim && state.settings.particles)) { fxRunning = false; ctx2d.clearRect(0, 0, fx.width, fx.height); return; }
  ctx2d.clearRect(0, 0, fx.width, fx.height);
  for (const p of particles) {
    p.x += p.vx + Math.sin(p.p += .01) * .15; p.y += p.vy;
    if (p.y < -10) { p.y = fx.height + 10; p.x = Math.random() * fx.width; }
    if (p.x < -10) p.x = fx.width + 10;
    if (p.x > fx.width + 10) p.x = -10;
    ctx2d.beginPath(); ctx2d.arc(p.x, p.y, p.r, 0, 6.283);
    ctx2d.fillStyle = `rgba(255,255,255,${p.a})`; ctx2d.fill();
  }
  requestAnimationFrame(fxLoop);
}
function applyFx() {
  const on = state.settings.anim && state.settings.particles;
  fx.style.display = on ? "block" : "none";
  if (on && !fxRunning) { fxRunning = true; requestAnimationFrame(fxLoop); }
}
addEventListener("resize", sizeFx);

document.addEventListener("mousemove", (e) => {
  if (!state.settings.anim) return;
  if (state.settings.parallax) {
    const px = -(e.clientX / innerWidth - .5) * 24, py = -(e.clientY / innerHeight - .5) * 24;
    $("bg").style.translate = `${px}px ${py}px`;
  }
  const t = e.target.closest && e.target.closest(".tile");
  if (t && !editing) {
    const r = t.querySelector(".ico").getBoundingClientRect();
    const dx = (e.clientX - (r.left + r.width / 2)) / r.width, dy = (e.clientY - (r.top + r.height / 2)) / r.height;
    t.style.setProperty("--ry", (dx * 22) + "deg");
    t.style.setProperty("--rx", (-dy * 22) + "deg");
  }
});
document.addEventListener("mouseout", (e) => {
  const t = e.target.closest && e.target.closest(".tile");
  if (t) { t.style.setProperty("--rx", "0deg"); t.style.setProperty("--ry", "0deg"); }
});

/* ---------- Démarrage ---------- */
function renderAll() { applyBody(); renderBg(); renderWidgets(); renderTiles(); }
["dlgShortcut", "dlgConfirm", "dlgSettings", "dlgGallery", "dlgWidget"].forEach((id) => wireDlg($(id)));
$("dlgGallery").addEventListener("close", () => { galleryPreviews.forEach((p) => p.destroy()); galleryPreviews = []; });
$("dlgWidget").addEventListener("close", () => { if (editorPreview) { editorPreview.destroy(); editorPreview = null; } if ($("dlgSettings").open) renderSettings(); });
(async () => {
  await load();
  sizeFx(); initParticles();
  renderAll();
  setTimeout(() => { enterAnim = false; }, 1500);
})();
